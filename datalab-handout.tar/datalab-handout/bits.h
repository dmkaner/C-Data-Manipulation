
int bitXor(int, int);
int test_bitXor(int, int);
int anyOddBit();
int test_anyOddBit();
int conditional(int, int, int);
int test_conditional(int, int, int);
int bitCount(int);
int test_bitCount(int);
int isTmin(int);
int test_isTmin(int);
int isLessOrEqual(int, int);
int test_isLessOrEqual(int, int);
int twosComp2SignMag(int);
int test_twosComp2SignMag(int);
unsigned floatAbsVal(unsigned);
unsigned test_floatAbsVal(unsigned);
unsigned floatScale4(unsigned);
unsigned test_floatScale4(unsigned);
